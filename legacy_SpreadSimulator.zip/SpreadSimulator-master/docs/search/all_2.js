var searchData=
[
  ['deathevent_14',['deathEvent',['../SpreadSimulator_8h.html#a86cade5b7ce3c1a516a4934e8eb1c36a',1,'SpreadSimulator.c']]],
  ['dehospitalizeevent_15',['dehospitalizeEvent',['../SpreadSimulator_8h.html#a1b76a018598a5525c3396f807ba43d9d',1,'SpreadSimulator.c']]]
];
