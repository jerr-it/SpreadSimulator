var searchData=
[
  ['hospitalizeevent_20',['hospitalizeEvent',['../SpreadSimulator_8h.html#ad63fe15d42ba8e865b6d0624531b1b32',1,'SpreadSimulator.c']]]
];
