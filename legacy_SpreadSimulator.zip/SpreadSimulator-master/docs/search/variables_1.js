var searchData=
[
  ['settings_119',['settings',['../structSpreadSimulator.html#ab0861579170948167ed0d3e9ca878b7b',1,'SpreadSimulator']]],
  ['stats_120',['stats',['../structSpreadSimulator.html#a7360893fbc69f717242e864f2686ea17',1,'SpreadSimulator']]]
];
