var searchData=
[
  ['savesettings_112',['saveSettings',['../SimulationSettings_8h.html#a98fdd10ac04151741a85a0ab4f822af6',1,'SimulationSettings.c']]],
  ['scalevector_113',['scaleVector',['../Vector2_8h.html#a3d00d01af201a0b7ed483f32f0018f8f',1,'Vector2.c']]],
  ['subdivide_114',['subdivide',['../Quadtree_8h.html#a1018a181c94e878b12a14aa9a11bd4c6',1,'Quadtree.c']]]
];
