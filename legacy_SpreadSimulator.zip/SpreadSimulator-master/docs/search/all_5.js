var searchData=
[
  ['getmagnitude_19',['getMagnitude',['../Vector2_8h.html#a8bb2a546c1a5aa92b97880d54f4fc5b9',1,'Vector2.c']]]
];
