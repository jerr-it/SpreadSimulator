import os

os.chdir("SpreadSimGUI")
os.system("./PandemiC")
